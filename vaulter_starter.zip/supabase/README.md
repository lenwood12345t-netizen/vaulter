Provision a Supabase project, then run the SQL in `migrations/`.

Set env vars in Vercel:
- SUPABASE_URL
- SUPABASE_ANON_KEY
- SUPABASE_SERVICE_ROLE
